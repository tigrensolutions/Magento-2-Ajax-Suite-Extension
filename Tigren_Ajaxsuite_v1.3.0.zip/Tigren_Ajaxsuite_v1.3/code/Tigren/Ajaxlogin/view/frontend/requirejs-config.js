/**
 * @copyright Copyright (c) 2017 www.tigren.com
 */

var config = {
    map: {
        '*': {
            'tigren/ajaxlogin': 'Tigren_Ajaxlogin/js/ajax-login'
        }
    }
};
