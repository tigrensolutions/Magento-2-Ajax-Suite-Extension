/**
 * @copyright Copyright (c) 2017 www.tigren.com
 */

var config = {
    map: {
        '*': {
            'tigren/swatchRenderer': 'Tigren_Ajaxwishlist/js/swatch-renderer',
            'tigren/ajaxwishlist': 'Tigren_Ajaxwishlist/js/ajax-wishlist',
            'tigren/ajaxremove': 'Tigren_Ajaxwishlist/js/ajax-remove'
        }
    }
};
