/**
 * @copyright Copyright (c) 2017 www.tigren.com
 */

var config = {
    map: {
        '*': {
            'tigren/ajaxcompare': 'Tigren_Ajaxcompare/js/ajax-compare'
        }
    }
};
